# Store Management System - LAROZA

## Overview

This is a full-stack web application for LAROZA (لاروزا), an internal store management system designed for employees. The system provides comprehensive inventory management, sales tracking, returns processing, and accounting capabilities, all with a complete Arabic interface using right-to-left (RTL) layout.

The application follows a modern web architecture with React frontend, Express.js backend, and PostgreSQL database, utilizing TypeScript throughout for type safety and better development experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development
- **UI Library**: Shadcn/ui components with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with RTL support and custom Arabic fonts (Cairo, Amiri)
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Layout**: Responsive design with sidebar navigation and RTL support

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints following standard HTTP conventions
- **Middleware**: Custom logging, CORS, and error handling
- **Development**: Hot reloading with Vite integration for full-stack development

### Database Architecture
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Design**: Normalized relational structure with proper foreign key relationships
- **Key Tables**:
  - Products: Core product information with model numbers
  - Product Inventory: Color/size matrix with quantities (6 colors × 8 sizes)
  - Sales: Transaction records with payment methods and channels
  - Sale Items: Line items linking products to sales
  - Returns: Return transactions with refund/exchange tracking
  - Expenses: Business expense tracking
  - Purchases: Supplier purchase records

### Data Flow Architecture
- **Product Management**: Multi-dimensional inventory tracking (color × size × quantity)
- **Sales Processing**: Automatic inventory deduction with payment fee calculations
- **Returns System**: Inventory restoration with accounting adjustments
- **Reporting**: Date-range filtering for sales, expenses, and profit/loss analysis

### Component Architecture
- **Modular Design**: Feature-based component organization
- **Shared Components**: Reusable UI components in `/components/ui`
- **Page Components**: Route-specific components in `/pages`
- **Form Components**: Specialized forms for sales, returns, and inventory management
- **Layout Components**: Consistent sidebar navigation and header structure

### Type Safety
- **Shared Schema**: Common TypeScript types between frontend and backend
- **Validation**: Zod schemas for runtime type checking and form validation
- **Database Types**: Drizzle-generated types for type-safe database operations

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver for database connectivity
- **drizzle-orm**: Type-safe ORM for PostgreSQL with migration support
- **@tanstack/react-query**: Server state management and caching

### UI and Styling Dependencies
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework with RTL support
- **class-variance-authority**: Type-safe CSS class composition
- **lucide-react**: Modern icon library

### Form and Validation Dependencies
- **react-hook-form**: Performant form library with validation
- **@hookform/resolvers**: Integration between React Hook Form and validation libraries
- **zod**: TypeScript-first schema validation

### Development Dependencies
- **vite**: Fast build tool and development server
- **typescript**: Static type checking
- **esbuild**: Fast JavaScript bundler for production builds

### Font Dependencies
- **Google Fonts**: Cairo and Amiri fonts for proper Arabic typography
- **Font Awesome**: Icon library for UI elements

### Database Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle Kit**: Database migration and schema management tools