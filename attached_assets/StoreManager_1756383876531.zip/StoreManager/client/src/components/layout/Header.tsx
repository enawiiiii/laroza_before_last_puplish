import { Button } from "@/components/ui/button";
import { useState } from "react";
import AddProductModal from "@/components/inventory/AddProductModal";

interface HeaderProps {
  title?: string;
  subtitle?: string;
}

export default function Header({ 
  title = "لوحة التحكم الرئيسية", 
  subtitle = "نظام إدارة متجر لاروزا الداخلي" 
}: HeaderProps) {
  const [showAddProduct, setShowAddProduct] = useState(false);

  return (
    <>
      <header className="bg-card border-b border-border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">{title}</h2>
            <p className="text-muted-foreground">{subtitle}</p>
          </div>
          <div className="flex items-center space-x-4 space-x-reverse">
            <Button 
              onClick={() => setShowAddProduct(true)}
              data-testid="button-add-product"
            >
              <i className="fas fa-plus mr-2 ml-0"></i>
              إضافة منتج جديد
            </Button>
            <div className="text-left">
              <p className="text-sm font-medium">
                اليوم: {new Date().toLocaleDateString('ar-EG', { weekday: 'long' })}
              </p>
              <p className="text-xs text-muted-foreground">
                {new Date().toLocaleDateString('ar-EG')}
              </p>
            </div>
          </div>
        </div>
      </header>
      
      <AddProductModal 
        open={showAddProduct} 
        onOpenChange={setShowAddProduct}
      />
    </>
  );
}
