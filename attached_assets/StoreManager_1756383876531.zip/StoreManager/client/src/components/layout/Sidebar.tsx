import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const navigationItems = [
  {
    href: "/dashboard",
    icon: "fas fa-chart-line",
    label: "لوحة التحكم",
    testId: "nav-dashboard"
  },
  {
    href: "/inventory", 
    icon: "fas fa-boxes",
    label: "إدارة المخزون",
    testId: "nav-inventory"
  },
  {
    href: "/sales",
    icon: "fas fa-shopping-cart", 
    label: "المبيعات",
    testId: "nav-sales"
  },
  {
    href: "/returns",
    icon: "fas fa-undo",
    label: "المرتجعات", 
    testId: "nav-returns"
  },
  {
    href: "/accounting",
    icon: "fas fa-calculator",
    label: "المحاسبة",
    testId: "nav-accounting"
  },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-card border-l border-border flex flex-col">
      {/* Logo Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3 space-x-reverse">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-store text-primary-foreground"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold text-primary">لاروزا</h1>
            <p className="text-sm text-muted-foreground">LAROZA</p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-2">
        {navigationItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <a
              data-testid={item.testId}
              className={cn(
                "flex items-center space-x-3 space-x-reverse p-3 rounded-lg text-sm font-medium transition-colors",
                location === item.href || (item.href === "/dashboard" && location === "/")
                  ? "sidebar-active"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
            >
              <i className={`${item.icon} w-5`}></i>
              <span>{item.label}</span>
            </a>
          </Link>
        ))}
      </nav>
    </div>
  );
}
