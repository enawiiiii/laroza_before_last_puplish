import { apiRequest } from "./queryClient";

export const api = {
  // Products
  getProducts: () => fetch("/api/products").then(res => res.json()),
  getProduct: (id: string) => fetch(`/api/products/${id}`).then(res => res.json()),
  createProduct: (data: { product: any; inventory: any[] }) => 
    apiRequest("POST", "/api/products", data),
  updateProduct: (id: string, data: any) =>
    apiRequest("PUT", `/api/products/${id}`, data),
  deleteProduct: (id: string) =>
    apiRequest("DELETE", `/api/products/${id}`),
    
  // Inventory
  getProductInventory: (productId: string) => 
    fetch(`/api/products/${productId}/inventory`).then(res => res.json()),
  updateInventory: (productId: string, data: { color: string; size: string; quantity: number }) =>
    apiRequest("PUT", `/api/products/${productId}/inventory`, data),
    
  // Sales
  getSales: () => fetch("/api/sales").then(res => res.json()),
  createSale: (data: { sale: any; items: any[] }) =>
    apiRequest("POST", "/api/sales", data),
    
  // Returns
  getReturns: () => fetch("/api/returns").then(res => res.json()),
  createReturn: (data: { return: any; items: any[] }) =>
    apiRequest("POST", "/api/returns", data),
    
  // Expenses
  getExpenses: () => fetch("/api/expenses").then(res => res.json()),
  createExpense: (data: any) =>
    apiRequest("POST", "/api/expenses", data),
    
  // Purchases
  getPurchases: () => fetch("/api/purchases").then(res => res.json()),
  createPurchase: (data: any) =>
    apiRequest("POST", "/api/purchases", data),
    
  // Dashboard
  getDashboardStats: () => fetch("/api/dashboard/stats").then(res => res.json()),
  
  // Reports
  getSalesReport: (startDate: string, endDate: string) =>
    fetch(`/api/reports/sales?startDate=${startDate}&endDate=${endDate}`).then(res => res.json()),
  getExpensesReport: (startDate: string, endDate: string) =>
    fetch(`/api/reports/expenses?startDate=${startDate}&endDate=${endDate}`).then(res => res.json()),
};
