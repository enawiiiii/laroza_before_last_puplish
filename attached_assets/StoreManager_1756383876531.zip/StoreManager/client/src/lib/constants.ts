export const COLORS = [
  { value: 'black', label: 'أسود', colorClass: 'bg-gray-900' },
  { value: 'white', label: 'أبيض', colorClass: 'bg-white border-2' },
  { value: 'red', label: 'أحمر', colorClass: 'bg-red-500' },
  { value: 'blue', label: 'أزرق', colorClass: 'bg-blue-500' },
  { value: 'green', label: 'أخضر', colorClass: 'bg-green-500' },
  { value: 'brown', label: 'بني', colorClass: 'bg-amber-700' },
] as const;

export const SIZES = [
  { value: '38', label: '38' },
  { value: '40', label: '40' },
  { value: '42', label: '42' },
  { value: '44', label: '44' },
  { value: '46', label: '46' },
  { value: '48', label: '48' },
  { value: '50', label: '50' },
  { value: '52', label: '52' },
] as const;

export const PRODUCT_TYPES = [
  { value: 'dress', label: 'فستان' },
  { value: 'evening-wear', label: 'فستان سهرة' },
  { value: 'hijab', label: 'حجاب' },
  { value: 'abaya', label: 'عباءة' },
  { value: 'accessories', label: 'إكسسوارات' },
] as const;

export const PAYMENT_METHODS = [
  { value: 'cash', label: 'نقداً' },
  { value: 'visa', label: 'فيزا (+5%)' },
  { value: 'bank-transfer', label: 'تحويل بنكي' },
  { value: 'cod', label: 'دفع عند الاستلام' },
] as const;

export const EXPENSE_CATEGORIES = [
  { value: 'rent', label: 'إيجار' },
  { value: 'salaries', label: 'رواتب' },
  { value: 'utilities', label: 'مرافق' },
  { value: 'other', label: 'أخرى' },
] as const;

export const SALES_CHANNELS = [
  { value: 'in-store', label: 'متجر' },
  { value: 'online', label: 'أونلاين' },
] as const;

export const STATUS_LABELS = {
  'in-stock': 'متوفر',
  'low-stock': 'مخزون قليل', 
  'out-of-stock': 'نفذ',
} as const;

export const RETURN_TYPES = [
  { value: 'refund', label: 'استرداد' },
  { value: 'exchange', label: 'استبدال' },
] as const;
